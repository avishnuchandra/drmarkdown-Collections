package com.drmarkdown.auth.exceptions;


import org.springframework.security.core.AuthenticationException;

/**
 * This file was created by aantonica on 19/05/2020
 */
public class MarkdownTokenAuthException extends AuthenticationException {
    public MarkdownTokenAuthException(String s) {
    super(s);
    }
}
