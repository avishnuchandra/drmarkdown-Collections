package com.drmarkdown.auth.dtos;

import lombok.Data;

import java.util.Date;

/**
 * This file was created by aantonica on 19/05/2020
 */
@Data
public class RoleDTO {

    private String role;
    private String id;
    private Date createdAt;
    private Date updatedAt;

}
