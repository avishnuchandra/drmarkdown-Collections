package com.drmarkdown.auth.models;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * This file was created by aantonica on 19/05/2020
 */
// Getters, setters and some other
@Data
@EqualsAndHashCode(callSuper = true)
@Document(collection = "users")
public class MarkdownUserModel extends GenericModel {

    @Indexed(direction = IndexDirection.DESCENDING, unique = true)
    private String username;

    @Indexed(direction = IndexDirection.DESCENDING, unique = true)
    private String displayName;

    @Indexed(direction = IndexDirection.DESCENDING, unique = true)
    private String email;

    private List<String> roles;
    private String jwtToken;
    private String password;

    public MarkdownUserModel() {
        super();
    }
}
