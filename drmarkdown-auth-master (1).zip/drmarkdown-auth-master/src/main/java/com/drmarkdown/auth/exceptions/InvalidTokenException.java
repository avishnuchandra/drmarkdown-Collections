package com.drmarkdown.auth.exceptions;

/**
 * This file was created by aantonica on 19/05/2020
 */
public class InvalidTokenException extends Exception {

    public InvalidTokenException(String message, RuntimeException e) {
        super(message, e);
    }

    public InvalidTokenException(String s) {
        super(s);
    }
}
