package com.drmarkdown.auth.dtos;

import lombok.Data;

/**
 * This file was created by aantonica on 19/05/2020
 */
 @Data
public class UserLoginDTO {

    private String username;
    private String password;
}
