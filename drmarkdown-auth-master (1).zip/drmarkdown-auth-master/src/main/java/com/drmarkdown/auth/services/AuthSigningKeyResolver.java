package com.drmarkdown.auth.services;

import io.jsonwebtoken.SigningKeyResolver;

import javax.crypto.SecretKey;

/**
 * This file was created by aantonica on 19/05/2020
 */
public interface AuthSigningKeyResolver extends SigningKeyResolver {

    SecretKey getSecretKey();

}
