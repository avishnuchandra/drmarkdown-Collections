package com.drmarkdown.auth.models;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * This file was created by aantonica on 19/05/2020
 */
@Data
@Document(collection = "roles")
@EqualsAndHashCode(callSuper = true)
public class MarkdownRoleModel extends GenericModel {

    private String role;

    public MarkdownRoleModel() {
        super();
    }
}
