package com.drmarkdown.auth.services;

import com.drmarkdown.auth.dtos.RoleDTO;

/**
 * This file was created by aantonica on 19/05/2020
 */
public interface RoleService {

    // role creation
    void createRole(RoleDTO roleDTO);

    // role information
    RoleDTO roleInfo(String roleId);
}
