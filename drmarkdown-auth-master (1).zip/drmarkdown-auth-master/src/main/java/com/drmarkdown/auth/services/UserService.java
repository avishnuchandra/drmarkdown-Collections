package com.drmarkdown.auth.services;

import com.drmarkdown.auth.dtos.UserInfoDTO;
import com.drmarkdown.auth.dtos.UserLoginDTO;

/**
 * This file was created by aantonica on 19/05/2020
 */
public interface UserService {

//     user creation
    void createUser(UserInfoDTO userInfoDTO);

//    user fetching
    UserInfoDTO retrieveUserInfo(String userId, String token);

//    user login
    UserInfoDTO loginUser(UserLoginDTO userLoginDTO);
}
