
export class DocModel {
    id: string;
    content: string;
    userId: string;
    title: string;
    available: boolean;
    createdAt: string;
    updatedAt: string;

}